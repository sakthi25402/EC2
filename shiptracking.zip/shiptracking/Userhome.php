<?php
include('Userheader.php');
error_reporting(0);
session_start();
?>

<div align="center">

<br>
<br>
<br>
<br>

<table>
<tr>
<td>
<font color="red"><b>Welcome:<?php echo $_SESSION['login_user'];?></b></font>
</td>
</tr>
</table>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<?php

?>


