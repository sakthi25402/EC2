<?php 
	
	include_once("Adminheader.php");
?>	



<style>
h1 {
  color: blue;
  font-family: verdana;
  font-size: 300%;

}
p  {
  color: gray;
  font-family: Georgia, serif;
  font-size: 140%;
   font-weight: bold;
}
</style>
<div align=center>		
			<br>
<h1>Welcome: Admin</h1>
</br>		
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
</div>
<?php			

?>
